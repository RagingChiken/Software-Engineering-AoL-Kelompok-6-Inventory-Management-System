document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('inventoryForm');
    const tableBody = document.getElementById('inventoryTable').getElementsByTagName('tbody')[0];

    // Load data from local storage on page load
    loadInventory();

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        const itemName = document.getElementById('itemName').value;
        const quantity = document.getElementById('quantity').value;
        const purchaseDate = document.getElementById('purchaseDate').value;
        const expirationDate = document.getElementById('expirationDate').value;
        const category = document.getElementById('category').value;
        const location = document.getElementById('location').value;

        const newItem = {
            itemName,
            quantity,
            purchaseDate,
            expirationDate,
            category,
            location
        };

        addItemToTable(newItem);
        saveItemToLocalStorage(newItem);

        form.reset();
    });

    function addItemToTable(item) {
        const newRow = tableBody.insertRow();

        newRow.innerHTML = `
            <td>${item.itemName}</td>
            <td>${item.quantity}</td>
            <td>${item.purchaseDate}</td>
            <td>${item.expirationDate}</td>
            <td>${item.category}</td>
            <td>${item.location}</td>
            <td><button onclick="deleteRow(this)">Delete</button></td>
        `;
    }

    function saveItemToLocalStorage(item) {
        let inventory = JSON.parse(localStorage.getItem('inventory')) || [];
        inventory.push(item);
        localStorage.setItem('inventory', JSON.stringify(inventory));
        checkExpirations();
    }

    function loadInventory() {
        const inventory = JSON.parse(localStorage.getItem('inventory')) || [];
        inventory.forEach(addItemToTable);
    }

    function checkExpirations() {
        let inventory = JSON.parse(localStorage.getItem('inventory')) || [];
        let now = new Date();
        let notifications = [];
        
        inventory.forEach(item => {
            let expirationDate = new Date(item.expirationDate);
            let timeDiff = expirationDate.getTime() - now.getTime();
            let dayDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));
            
            if (dayDiff <= 7) {
                notifications.push(`${item.itemName} is expiring in ${dayDiff} day(s)!!!`);
            }
        });
        
        displayNotifications(notifications);
    }
    
    function displayNotifications(notifications) {
        let notificationDiv = document.getElementById('notifications');
        notificationDiv.innerHTML = '';
        
        notifications.forEach(notification => {
            let p = document.createElement('p');
            p.innerText = notification;
            notificationDiv.appendChild(p);
        });
    }

    checkExpirations();
    setInterval(checkExpirations, 24 * 60 * 60 * 1000);

    window.deleteRow = function(button) {
        const row = button.parentNode.parentNode;
        const itemName = row.cells[0].innerText;

        row.parentNode.removeChild(row);

        let inventory = JSON.parse(localStorage.getItem('inventory')) || [];
        inventory = inventory.filter(item => item.itemName !== itemName);
        localStorage.setItem('inventory', JSON.stringify(inventory));
    }
});
