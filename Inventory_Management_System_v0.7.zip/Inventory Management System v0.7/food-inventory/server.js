const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(bodyParser.json());
app.use(cors());

let inventory = [];

app.post('/add-item', (req, res) => {
    const newItem = req.body;
    inventory.push(newItem);
    res.json({ message: 'Item added successfully' });
});

app.get('/inventory', (req, res) => {
    res.json(inventory);
});

app.listen(3000, () => {
    console.log('Server is running on port 3000');
});
